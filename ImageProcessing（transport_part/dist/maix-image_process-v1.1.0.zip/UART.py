
from maix import  uart
from struct import pack

from numpy import info

# cam = camera.Camera()
# dis = display.Display()

def Uart(info_send1,info_send2,info_send3):
    devices = uart.list_devices()
    serial = uart.UART(devices[0], 115200, uart.BITS.BITS_8, uart.PARITY.PARITY_NONE, uart.STOP.STOP_1)  
    
    # num = 10
    bytes_content = b'\xFF'     #信号开头
    bytes_content += b'\xBB'     #传送带停止指令
    bytes_content += pack(">h",info_send1)      #用char类型会溢出，只能用两个字节
    # bytes_content += pack("<i", num)  #将字符串转成二进制数据
    if info_send2 < 0:
        info_send2 = 0 - info_send2
        print(type(info_send2))
        print(info_send2)
        bytes_content += b'\xDD'     #一个数值传输量 
        
        bytes_content += pack(">B",info_send2)     #一个数值传输量
        
    else :
        info_send2 = info_send2
        print(type(info_send2))
        print(info_send2)
        bytes_content += b'\xCC'     #一个数值传输量 
        bytes_content += pack(">B",info_send2)     #一个数值传输量 

    bytes_content += info_send3
    print(bytes_content, type(bytes_content))
    serial.write(bytes_content)

def Order():
    devices = uart.list_devices()
    serial = uart.UART(devices[0], 115200, uart.BITS.BITS_8, uart.PARITY.PARITY_NONE, uart.STOP.STOP_1)

    order_content = b'\xAA'   #现在尚未确定命令电机运动的校验码为何，先空着

    serial.write(order_content)
'''
serial.write_str("hello world")
print("received:", serial.read(timeout = 2000))

cam = camera.Camera()
dis = display.Display()
'''

