#----------------
# main.py
#----------------
#内容：  创建 摄像头cam, 预处理图像img_ori
#        操作 图像处理函数, 识别函数, 界面操作系统函数
#        
#----------------
#创建时间： 2025.3.6
#创建人：yst2219
#----------------


import os
os.chdir(os.path.dirname(__file__))

from maix import camera, app, time
#import numpy as np
#import cv2

from UART import Uart      #请无视这个红线
from Img_Processing import image_processing

flag = 0

cam = camera.Camera(200, 200)       #配置摄像头
cam.skip_frames(30)                 #跳过前三十帧

'''
def Uart(info_send1,info_send2,info_send3):
    devices = uart.list_devices()
    serial = uart.UART(devices[0], 115200, uart.BITS.BITS_8, uart.PARITY.PARITY_NONE, uart.STOP.STOP_1)  
    
    # num = 10
    bytes_content = b'\xFE'     #信号开头
    bytes_content += b'\xAA'     #传送带停止指令
    bytes_content += pack("<h",info_send1)      #用char类型会溢出，只能用两个字节
    # bytes_content += pack("<i", num)  #将字符串转成二进制数据

    bytes_content += pack("<h",info_send2)     #一个数值传输量 
    bytes_content += info_send3
    bytes_content += b'\xFF'
    print(bytes_content, type(bytes_content))
    serial.write(bytes_content)
'''

'''
#以下是识别圆的代码
def Circle_find(thresholds_color: list[list[int]], img: image.Image):
    
    # 图像坐标为：(a.x(),a.y()),直径为 a.r() ; 或 corners (内含所识别到的红色占据图中矩形的四点坐标)
    
    circles = img.find_circles(threshold = 4000,x_margin=20,y_margin=20,r_margin=20,r_min=45,r_max=62,r_step=5)
    #以下是识别 某种颜色圆 的代码
    color_blobs = img.find_blobs(thresholds_color, area_threshold = 100, pixels_threshold = 100)
    for b in color_blobs:
        corners = b.corners()
        for a in circles:
            for i in range(4):
                img.draw_circle(a.x(), a.y(), a.r(), image.COLOR_RED, 2)
                img.draw_line(corners[i][0], corners[i][1], corners[(i + 1) % 4][0], corners[(i + 1) % 4][1], image.COLOR_BLUE)
                img.draw_string(a.x() + a.r() + 5, a.y() + a.r() + 5, "r: " + str(a.r()) + "magnitude: " + str(a.magnitude()), image.COLOR_RED)
                print(a.x(),a.y(),a.r())
                #return a._getitem_()
                return a
'''

'''
#以下是识别矩形的代码
def Rectangular_find(thresholds_color: list[list[int]], img: image.Image):
    
    # 图像坐标为：[    (rect[0]        ,    rect[1]        ),
    #                 (rect[0]+rect[2],    rect[1]        ),
    #                 (rect[0]+rect[2],    rect[1]+rect[3]),
    #                 (rect[0]        ,    rect[1]+rect[3])]  顺序为顺时针

    #以下是识别 某种颜色矩形 的代码 
    #此处颜色识别效果不太好，最好应先识别矩形再判断颜色，但出于最终用颜色统一函数的需求，在此先判断颜色。使用时应将摄像头摆放在矩形大约18cm——19cm 
    color_blobs = img.find_blobs(thresholds_color, area_threshold = 100, pixels_threshold = 100)
    for b in color_blobs:
            corners = b.corners()
            RECT = b.rect()
            rects = img.find_rects(roi=[RECT[0]-20000,RECT[1]-20000,RECT[2]+20000,RECT[3]+20000], threshold = 69500)
            for a in rects:
                rect = a.rect()
                for i in range(4):
                    img.draw_rect(rect[0],rect[1],rect[2],rect[3],image.COLOR_RED)
                    img.draw_line(corners[i][0], corners[i][1], corners[(i + 1) % 4][0], corners[(i + 1) % 4][1], image.COLOR_BLUE)
                    img.draw_string(rect[0] + 5, rect[1] + 5, "rect", image.COLOR_RED)
                    img.draw_string(rect[0] + 5, rect[1] + 20, "magnitude: " + str(a.magnitude()), image.COLOR_RED)
                    return rect
'''

'''
#以下是识别三角形和梯形（近似为四边形）的代码
def TrigATrapz_find(LAB_thresholds, img):
    import cv2
    import numpy as np
    kernel = np.ones((3,3), np.uint8)        #创建核
    i =0

    img_raw = image.image2cv(img,ensure_bgr=False,copy=False)
    img_ = cv2.cvtColor(img_raw,cv2.COLOR_BGR2LAB)   #RGB转LAB
    #LAB_thresholds = [[0,71,-4,77,36,79]]    #原为红值，现为蓝值且后四项两组反转
    #LAB_thresholds = [[0,61,-128,127,-128,-30]]     #原为蓝值，现为红值
    #LAB_thresholds= [[0,70,-128,65,-128,33]]        #原为绿值，现也为绿值

    # 解析LAB阈值参数（OpenCV的LAB范围特性是：L(0~255)；A(-128~127);B(-128~127)）
    Lmin,Lmax,Amin,Amax,Bmin,Bmax = LAB_thresholds[0]   #创建LAB通道的高低

    lower_bound = np.array([Lmin*255/100, Amin+128, Bmin+128])  #上下界限
    upper_bound = np.array([Lmax*255/100, Amax+128, Bmax+128])
    
    mask = cv2.inRange(img_, lower_bound, upper_bound)
        #第一个参数：src指的是原图
        #第二个参数：lower_red指的是图像中低于这个lower_red的值，图像值变为0
        #第三个参数：upper_red指的是图像中高于这个upper_red的值，图像值变为0
        #而在lower_red～upper_red之间的值变成255

    # if LAB_thresholds[0][3] <= 70:                               #绿色时掩图就取反
    #     mask = cv2.bitwise_not(mask)

    #img_raw = cv2.bitwise_and(img_raw,img_raw,mask=mask)        #颜色已抓取

    img_= cv2.GaussianBlur(mask,(5,5),0)     #高斯滤波
    img_= cv2.bilateralFilter(img_, 9, 75, 75) #双边滤波(去噪点)
    
    _, thresh = cv2.threshold(img_, 127, 255, cv2.THRESH_BINARY) #二值化
    #thresh = cv2.morphologyEx(img_raw, cv2.MORPH_OPEN, kernel)
    thresh = cv2.morphologyEx(img_, cv2.MORPH_CLOSE, kernel) #闭运算(去噪点)  
    edged = cv2.Canny (thresh, 200, 600)    #Canny找边缘
    contours, _ = cv2.findContours(edged, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE) #findContours找角点
    if len(contours) > 0:
        #筛选出最大的轮廓
        largest_contour = max(contours, key=cv2.contourArea)
    
        epsilon =0.02 * cv2.arcLength(largest_contour,True)
        approx = cv2.approxPolyDP(largest_contour, epsilon, True) #approxPolyDP逼近多边形   approx格式为:[[[x1 y1]] [[x2 y2]] [[x3 y3]]]
        # if len(approx) > 10:  #如果角点数>=3
        #     print("这是圆")
        #     cv2.drawContours(img_raw, [approx], 0, (0, 255, 0), 3)
        if len(approx) == 3:
            # rect = cv2.minAreaRect(approx)  #获取最小外接矩形
            # points = cv2.boxPoints(rect)     #最小外接矩形的四点(顺序：右下；左下；右上；左上)
            # # center = rect[0]            
            print("这是一个"+str(len(approx))+"边形")  
            # print(points)
            # cv2.drawContours(img_raw, [approx], 0, (0, 255, 0), 3)   #drawContours画出轮廓
            for point in approx:
                x, y = point.ravel()    #获取每个多边形角点坐标
                cv2.circle(img=img_raw,center=(x,y),radius=5,color=(255,0,0),thickness=2) #circle画出多边形角点
                approx = approx.tolist()                                                  #approx从array转list，防止下面判断报错
                return approx                                                             #不测试的话就把point循环给删了，直接输出approx
                
        elif len(approx) == 4 :
            print("这是一个"+str(len(approx))+"边形")
            #cv2.drawContours(img_raw, [approx], 0, (0, 255, 0), 3)   #drawContours画出轮廓
            for point in approx:
                x, y = point.ravel()    #获取每个多边形角点坐标
                cv2.circle(img=img_raw,center=(x,y),radius=5,color=(255,0,0),thickness=2) #circle画出多边形角点
                approx = approx.tolist()
                return approx
'''

'''   
def image_processing(img):

    circle = Circle_find(thresholds_object1, img)
    rectangular = Rectangular_find(thresholds_object2, img)
    if circle != None:
        object = [b'\x01',3,[circle.x(),circle.y(),circle.r()]]   #格式为[形状，参数数量，参数列表]
        circle = None
        
        fps = time.fps()                # Calculate FPS between last time fps() call and this time call.
                                        # | 计算两次 fps 函数调用之间的帧率
        print(f"time: {1000/fps:.02f}ms, fps: {fps:.02f}")  #在终端打印帧率 (FPS)

        return object
    
    elif rectangular !=None:
        object = [b'\x02',4,rectangular]
        rectangular = None
        fps = time.fps()                # Calculate FPS between last time fps() call and this time call.
                                        # | 计算两次 fps 函数调用之间的帧率
        print(f"time: {1000/fps:.02f}ms, fps: {fps:.02f}")  #在终端打印帧率 (FPS)

        return object
 
    # else:
    #     trig_a_trapz = TrigATrapz_find(thresholds_object1, img)
    #     if trig_a_trapz != None:
    #         if len(trig_a_trapz) == 3:
    #             object = [b'\x03',3,[trig_a_trapz[0][0],trig_a_trapz[1][0],trig_a_trapz[2][0]]]
    #             trig_a_trapz = None
    #             fps = time.fps()                # Calculate FPS between last time fps() call and this time call.
    #                                             # | 计算两次 fps 函数调用之间的帧率
    #             print(f"time: {1000/fps:.02f}ms, fps: {fps:.02f}")  #在终端打印帧率 (FPS)
                
    #             return object
    #         else:
    #             object = [b'\04',4,[trig_a_trapz[0][0],trig_a_trapz[1][0],trig_a_trapz[2][0],trig_a_trapz[3][0]]]
    #             trig_a_trapz = None
    #             fps = time.fps()                # Calculate FPS between last time fps() call and this time call.
    #                                             # | 计算两次 fps 函数调用之间的帧率
    #             print(f"time: {1000/fps:.02f}ms, fps: {fps:.02f}")  #在终端打印帧率 (FPS)

    #             return object
    

    disp.show(img)
'''

'''
def Image_Processing():
    while 1:
        img = cam.read()

        disp.show(img)
        #以下是识别蓝色矩形的代码
        #第一种(可能会误测到周边环境)
        blue_blobs = img.find_blobs(thresholds_blue, area_threshold = 100, pixels_threshold = 100)
        rects = img.find_rects(threshold = 69500)
        for b in blue_blobs:
            corners = b.corners()
            RECT = b.rect()
            for a in rects:
                rect = a.rect()
                for i in range(4):
                    img.draw_rect(rect[0],rect[1],rect[2],rect[3],image.COLOR_RED)
                    img.draw_line(corners[i][0], corners[i][1], corners[(i + 1) % 4][0], corners[(i + 1) % 4][1], image.COLOR_BLUE)
                    img.draw_string(rect[0] + 5, rect[1] + 5, "rect", image.COLOR_RED)
                    img.draw_string(rect[0] + 5, rect[1] + 20, "magnitude: " + str(a.magnitude()), image.COLOR_RED)      
        #第二种（反应很慢，但准）
        blue_blobs = img.find_blobs(thresholds_blue, area_threshold = 100, pixels_threshold = 100)
        for b in blue_blobs:
            corners = b.corners()
            RECT = b.rect()
            rects = img.find_rects(roi=[RECT[0]-20000,RECT[1]-20000,RECT[2]+20000,RECT[3]+20000], threshold = 69500)
            for a in rects:
                rect = a.rect()
                for i in range(4):
                    img.draw_rect(rect[0],rect[1],rect[2],rect[3],image.COLOR_RED)
                    img.draw_line(corners[i][0], corners[i][1], corners[(i + 1) % 4][0], corners[(i + 1) % 4][1], image.COLOR_BLUE)
                    img.draw_string(rect[0] + 5, rect[1] + 5, "rect", image.COLOR_RED)
        
    #以下是识别三角形和梯形（近似为四边形）的代码
    while 1:
        img = cam.read()
        red_blobs = img.find_blobs(thresholds_red, area_threshold = 100, pixels_threshold = 100)
        for b in red_blobs:
            corners = b.corners()
            trig = find_polygon(img)  #img为待处理图像,3为所要找的多边形角点数
            trapz = find_polygon(img)
            print(trig)
            disp.show(trig) #输出一次开运算的图像5秒   
'''    
    


def main():
    while not app.need_exit():
        img = cam.read()
        object = image_processing(img)
        # print("3")
        if object == None:
            continue
        elif object[0] == b'\x01':         #圆形
            ratio = object[2][2] / 225     # pixel / 0.1mm 
            distance_x = int((100 - object[2][0]) * ratio) + 730    #要求物块在视野内从左到右，否则该值取相反数
            distance_y = int((100 - object[2][1]) * ratio)
            sort = object[0]

            
        # elif object[0] == b'\x02':         #正方形
        #     ratio = object[2][2] / 225
        #     ratio += object[2][3] /225
        #     ratio = ratio / 2
        #     distance_x = int((100 - object[2][0] - 0.5*object[2][2]) * ratio) + 730
        #     distance_y = int((100 - object[2][1] - 0.5*object[2][3]) * ratio)
        #     sort = object[0]
            
        
        # elif object[0] ==b'\x03':          #三角形 [[a,b],[],[],[]]
        #     x1 = object[2][0][0]
        #     x2 = object[2][1][0]
        #     x3 = object[2][2][0]
        #     y1 = object[2][0][1]
        #     y2 = object[2][1][1]
        #     y3 = object[2][2][1]
        #     center = [int(x1/3+x2/3+x3/3), int(y1/3+y2/3+y3/3)]
        #     ratio = (((x1-x2) ** 2+(y1-y2) ** 2) ** 0.5) / 450 
        #     distance_x = int((100 - center[0]) * ratio) + 730
        #     distance_y = int((100 - center[1]) * ratio)
        #     sort = object[0]
        
        # elif object[0] ==b'\x04':
        #     x1 = object[2][0][0]
        #     x2 = object[2][1][0]
        #     x3 = object[2][2][0]
        #     x4 = object[2][3][0]
        #     y1 = object[2][0][1]
        #     y2 = object[2][1][1]
        #     y3 = object[2][2][1]
        #     y4 = object[2][3][1]
        #     center = [int(x1/4+x2/4+x3/4+x4/4),int(y1/4+y2/4+y3/4+y4/4)]
        #     ratio = (((x1-center[0]) ** 2+(y1-center[1]) ** 2) ** 0.5) / 270    #270mm 为梯形角点到重心的距离
        #     distance_x = int((100 - center[0]) * ratio) + 730
        #     distance_y = int((100 - center[1]) * ratio)
        #     sort = object[0]
        

        print (distance_x,"\t\t",distance_y,"\t\t")
        # time.sleep_ms(1000)
        Uart(distance_x,distance_y,sort)

        fps = time.fps()                # Calculate FPS between last time fps() call and this time call.
                                    # | 计算两次 fps 函数调用之间的帧率
        print(f"time: {1000/fps:.02f}ms, fps: {fps:.02f}")  #在终端打印帧率 (FPS)
        # time.sleep_ms(1000)

if __name__ == "__main__":
    main()
    
