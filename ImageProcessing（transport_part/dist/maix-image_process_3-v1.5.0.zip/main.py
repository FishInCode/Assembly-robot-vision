#----------------
# main.py
#----------------
#内容：  创建 摄像头cam, 预处理图像img_ori
#        操作 图像处理函数, 识别函数, 界面操作系统函数
#        
#----------------
#创建时间： 2025.3.6
#创建人：yst2219
#----------------


import os

from numpy import void
os.chdir(os.path.dirname(__file__))

from maix import app, time, display
#import numpy as np
#import cv2
from Img_Processing_1 import image_processing_1

def main():

    while not app.need_exit():

        time.fps_start()
        # img = img.lens_corr(strength=1.2)	# 调整strength的值直到画面不再畸变
        image_processing_1()
        time.sleep(5)       #识别并输出后，停止进入image_processing函数5秒
        # if object == None:                  #啥都没有
        #     # print('ABC')
        #     continue

        # elif object[0] == b'\x0A':          #圆形
            # # if flag_1 ==0 :                  #用于提前停下传送带
            # #     flag_1 += 1
            # #     # Uart(b'\x00',b'\x00',67,b'\x00')
            # #     time.sleep_ms(5)       #等待传送带停止
            # #     continue
            # # else:
            # ratio = 22.5 / object[2][2]     # 1mm/pixle 
            # distance_x_dif = 67 - int((100 - object[2][0]) * ratio * 1.4)     #要求物块在视野内从左到右，否则该值取相反数
            # print(distance_x_dif)
            # # if distance_x_dif in range(4,20):
            # flag_1= 0
            # while 1:        #要停得慢，识别得快，但是不能提前识别
            #     if FFFlag == 5:
            #         FFFlag += 1     #第六次时停传送带
            #         # distance_x += distance_x_dif
            #         Uart(b'\x00',b'\x00',67,b'\x00')
            #         continue
            #     elif FFFlag in range(0,5):
            #         FFFlag += 1     #空识别五次
            #         # distance_x += distance_x_dif
            #         continue
            #     elif FFFlag in range(6,10):
            #         FFFlag += 1     #空识别四次
            #         # distance_x += distance_x_dif
            #         continue
            #     elif FFFlag in range(10,111):       #加和100次
            #         FFFlag += 1
            #         distance_x += distance_x_dif
            #         continue
            #     else:
            #         # FFFlag = 0
            #         distance_x = int(distance_x/100)
            #         print(distance_x)
            #         force = object[3]
            #         if distance_x > 134:
            #             distance_x = 134
            #         elif distance_x <0:
            #             distance_x = 0
            #         Uart(object[0],force,distance_x,b'\xFC')
            #         break
                


                # print (distance_x)
                # # distance_y = int((object[2][1] - 100) * ratio)  #物块在中心点偏下，则y值为正；反之为负
                # force = object[3]
                # if distance_x > 134:
                #     distance_x = 134

                # # print (distance_x,"\t\t",distance_y,"\t\t",object[0],"\t\t")  
                # Uart(object[0],force,distance_x,b'\xFC')

            
        # elif object[0] == b'\x0B':          #正方形
        #     if flag_1 == 0:
        #         flag_1 += 1
        #         Uart(b'\x00',b'\x00',67,b'\x00')
        #         time.sleep_ms(50)       #等待传送带停止
        #         continue
        #     # if len(object[2]) != object[1] :                  #用于提前停下传送带

        #     #     Uart(b'\x00',b'\x00',67,b'\x00')
        #     #     time.sleep_ms(20)       #等待传送带停止
        #     #     continue
        #     else:
        #         # print (object)
        #         ratio = 45 / object[2][2]         # 45mm/pixle

        #         distance_x = int(object[2][0] * ratio)      #单位mm
        #         # print (distance_x)
        #         # if distance_x in range(65,130):
        #         distance_x = 67 - int((object[2][0]) * ratio *1.4)
        #         distance_y = int((object[2][1] - 100) * ratio)
        #         force = object[3]
        #         if distance_x > 134:
        #             distance_x = 134
        #         elif distance_x <0:
        #             distance_x = 0
        #         print (distance_x,"\t\t",distance_y,"\t\t",object[0],"\t\t")  

        #         Uart(object[0],force,distance_x,b'\xFC')
            
        # elif object[0] ==b'\x0C':           #三角形 [  ,  ,[ x, y, w, h],  ]
        #     if flag_1 == 0 :                 #用于提前停下传送带
        #         flag_1 += 1
        #         Uart(b'\x00',b'\x00',67,b'\x00')
        #         continue
        #     else:
        #         # print('3')
        #         ratio1 = 45 / object[2][2]
        #         ratio2 = 45 / object[2][3]
        #         ratio = (ratio1 + ratio2) / 2
        #         center = [ object[2][0], object[2][1]]

        #         distance_x = int((100 - center[0]) * ratio)
        #         # flag_1= 0
        #         print(distance_x)
        #         # if distance_x in range(-45,-22):
        #         distance_x = 67 - int((100 - center[0]) * ratio * 1.4)  + 20 #减1或加1都会导致偏向喻，但是数值为9时便会夹取正中间（虽然放置时会偏喻
        #         distance_y = 67 - int((100 - center[1]) * ratio *1.4)
        #         force = object[3]
        #         print (distance_x,"\t\t",distance_y,"\t\t",object[0],"\t\t")
        #         # time.sleep_ms(1000)
        #         Uart(object[0],force,distance_x,b'\xFC')
                        
        elif object[0] ==b'\x0C':           #三角形 [  ,  ,[ x, y, w, h],  ]
            # if flag_1 == 0 :                 #用于提前停下传送带
            #     Uart(b'\x00',b'\x00',67,b'\x00')
            #     flag_1 += 1

            #     # time.sleep_ms(50)
            #     continue
            # else:
                # print('3')
            ratio1 = 45 / object[2][2]
            ratio2 = 45 / object[2][3]
            ratio = (ratio1 + ratio2) / 2
            center = [ object[2][0], object[2][1]]

            # distance_x = int((100 - center[0]) * ratio)
            # flag_1= 0
            # if distance_x in range(-45,-22):
            distance_x = 67 - int((100 - center[0]) * ratio * 1.4)  #减1或加1都会导致偏向喻，但是数值为9时便会夹取正中间（虽然放置时会偏喻
            print(distance_x)
            # distance_y = 67 - int((100 - center[1]) * ratio *1.4)
            force = object[3]

            if distance_x > 134:
                distance_x = 134
            elif distance_x <0:
                distance_x = 0
            # print (distance_x,"\t\t",distance_y,"\t\t",object[0],"\t\t")    
            Uart(object[0],force,distance_x,b'\xFC')

        # elif object[0] ==b'\x0D':           #梯形 [  ,  ,[ x, y, w, h],  ]
        #     if flag_1 == 0:
        #         flag_1 += 1
        #         Uart(b'\x00',b'\x00',67,b'\x00')
        #         time.sleep_ms(500)
        #         continue
        #     else:
        #         ratio1 = 45 / object[2][2]
        #         ratio2 = 45 / object[2][3]
        #         ratio = (ratio1 + ratio2) / 2
        #         center =  [ object[2][0], object[2][1]]

        #         # distance_x = int((100 - center[0]) * ratio)
        #         # if distance_x in range(-20,20):
        #         distance_x = 67 - int((100 - center[0]) * ratio * 1.4)+25
        #         print(distance_x)
        #         distance_y = int((100 - center[1]) * ratio)
        #         force = object[3]
        #         if distance_x > 134:
        #             distance_x = 134
        #         elif distance_x <0:
        #             distance_x = 0
        #         print (distance_x,"\t\t",distance_y,"\t\t",object[0],"\t\t")  
        #         Uart(object[0],force,distance_x,b'\xFC')
        FFFlag = 0


if __name__ == "__main__":
    main()
    
