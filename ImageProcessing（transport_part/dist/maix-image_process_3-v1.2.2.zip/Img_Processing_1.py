#----------------
#图像处理_1: LAB通道调参 | 高斯、双边滤波 | 开操作一次 | Canny边缘检测（慢）| Cv2库的识别角点和逼近多边形

#Img_Precessing.py
#功能：传送带识别(包括形状识别、位置识别)
#----------------
#2025.3.6 ———2025.
#yst2219 
#----------------
#
# 
#------------------------------------------------------------问题：

from maix import image, display, time, nn, time

   
disp=display.Display()
detector1 = nn.YOLOv5(model="/root/models/maixhub/196357/model_196357.mud", dual_buff = True)
detector2 = nn.YOLOv5(model="/root/models/maixhub/196617/model_196617.mud", dual_buff = True)
# thresholds_red = [[0,71,36,79,-4,77]]        #red LABx
# thresholds_blue = [[0,61,-128,127,-128,-30]]    #blue LAB
thresholds_green = [[0,70,-128,-10,0,33]]      #green LAB
# thresholds_object1= [[61,83,-6,4,-4,7]]             # white LAB适用于圆、三角形、梯形
# thresholds_object2= [[53,79,-2,10,-1,10]]           # white LAB正方形专用
thresholds_object1_On= [[56,83,-6,4,-4,7]]                 # 上机后的white阈值 圆形
thresholds_object2_On= [[45,74,-1,17,-12,10]]           # 上机white LAB正方形专用 注意：后两个值范围分别是(-129,-10),(10,127)
# thresholds_object3_On= [[66,100,-19,17,-10,2]]         # 上机后的white阈值 三角形 梯形(?)
# thresholds_object3_OnL= [[78,100,-19,17,-10,2]]         # 上机后的white阈值 三角形 梯形(?)
thresholds_object4_On= [[45,90,-4,17,-10,6]]            # 上机后的white阈值 梯形 注意：第三个值范围为(-4,0)后两个值分别取低取高无所谓

# thresholds_object2= [[56,69,-3,10,-1,10]]                             
#识别传送带物块  68,-02,02rect 71,-03,00circle
#thresholds_green = [[21,41,-34,-14,-5,15]]     #green LAB#识别履带(自动采的也不知道好不好)

'''
颜色切换还是太复杂了，相比于每种颜色判断都切换对应的颜色参数，能不能直接通过改变图像格式只使用一个参数？
e.g.    仅使用识别红色参数,在识别蓝色时将图像格式从RGB切换为BGR
'''

#以下是识别圆的代码
def Circle_find(thresholds_color: list[list[int]], img: image.Image):
    
    # 图像坐标为：(a.x(),a.y()),直径为 a.r() ; 或 corners (内含所识别到的红色占据图中矩形的四点坐标)
    
    circles = img.find_circles(threshold = 4000,x_margin=20,y_margin=20,r_margin=20,r_min=75,r_max=90,r_step=5)   #rmin = 45
    #以下是识别 某种颜色圆 的代码
    color_blobs = img.find_blobs(thresholds_color, area_threshold = 100, pixels_threshold = 100)
    for b in color_blobs:
        corners = b.corners()
        for a in circles:
            return a

#以下是识别矩形的代码
def Rectangular_find(img: image.Image):         #色块识别不尽人意，先暂时转用Yolov5算法

    #以下是识别 白色颜色矩形 的代码 
    objs = detector1.detect(img, conf_th = 0.4, iou_th = 0.35)
    for obj in objs:
        if obj.class_id == 1:
            distance_x = obj.x+(obj.w/2)-100
            distance_y = obj.y+(obj.h/2)-100
            # print(distance_x,"\t\t",distance_y)
            if distance_x in range(-20,20):
                # print(distance_x,"\t\t",distance_y)
                # img.draw_line( obj.x, obj.y, obj.x + obj.w, obj.y + obj.h, color = image.COLOR_BLUE)
                # img.draw_rect(obj.x, obj.y, obj.w, obj.h, color = image.COLOR_RED)
                # msg = f'{detector.labels[obj.class_id]}: {obj.score:.2f}'
                # img.draw_string(obj.x, obj.y, msg, color = image.COLOR_RED)
                Rect = [distance_x + 100, distance_y + 100, obj.w, obj.h]
                return Rect

def Trig_find(img: image.Image):
    objs = detector2.detect(img, conf_th = 0.4, iou_th = 0.35)
    for obj in objs:
        if obj.class_id == 0:
            distance_x = obj.x+(obj.w/2)-100
            distance_y = obj.y+(obj.h/2)-100
            if distance_x in range(-20,20):
                Trig = [distance_x + 100, distance_y + 100, obj.w, obj.h]
                return Trig

def Trapz_find(thresholds,img):
    img_width  = img.size._getitem_(index = 0)
    img_height = img.size._getitem_(index = 1)
    img_format = img.format()
    mask = image.Image(img_width,img_height,img_format)

    #如何将cv库中颜色识别方法套用得到这里的mask有一定难度
    img_= img.b_and(mask)
    img_edge = img_.find_edges(edge_type = image.EdgeDetector.EDGE_CANNY,threshold = [50, 100])
    lines = img_edge.find_lines()
    for line in lines:
        theta = line.theta()


    

'''
# 以下是识别三角形和梯形（近似为四边形）的代码
def TrigATrapz_find(img: image.Image):
    import cv2
    import numpy as np
    kernel = np.ones((3,3), np.uint8)        #创建核
    # i =0

    img_raw = image.image2cv(img,ensure_bgr=False,copy=False)
    img_ = cv2.cvtColor(img_raw,cv2.COLOR_RGB2LAB)   #RGB转LAB
    #LAB_thresholds = [[0,71,-4,77,36,79]]    #原为红值，现为蓝值且后四项两组反转
    #LAB_thresholds = [[0,61,-128,127,-128,-30]]     #原为蓝值，现为红值

    # 解析LAB阈值参数（OpenCV的LAB范围特性是：L(0~255)；A(-128~127);B(-128~127)）
    Lmin,Lmax,Amin,Amax,Bmin,Bmax = LAB_thresholds[0]   #创建LAB通道的高低

    lower_bound = np.array([Lmin*255/100, Amin+128, Bmin+128])  #上下界限
    upper_bound = np.array([Lmax*255/100, Amax+128, Bmax+128])
    
    mask = cv2.inRange(img_, lower_bound, upper_bound)
        #第一个参数：src指的是原图
        #第二个参数：lower_red指的是图像中低于这个lower_red的值，图像值变为0
        #第三个参数：upper_red指的是图像中高于这个upper_red的值，图像值变为0
        #而在lower_red～upper_red之间的值变成255

    # if LAB_thresholds[0][3] <= 70:                               #绿色时掩图就取反
    #     mask = cv2.bitwise_not(mask)

    #img_raw = cv2.bitwise_and(img_raw,img_raw,mask=mask)        #颜色已抓取

    img_= cv2.GaussianBlur(mask,(5,5),0)     #高斯滤波
    img_= cv2.bilateralFilter(img_, 9, 75, 75) #双边滤波(去噪点)
    
    _, thresh = cv2.threshold(img_, 127, 255, cv2.THRESH_BINARY) #二值化
    #thresh = cv2.morphologyEx(img_raw, cv2.MORPH_OPEN, kernel)
    thresh = cv2.morphologyEx(img_, cv2.MORPH_CLOSE, kernel) #闭运算(去噪点)  
    edged = cv2.Canny (thresh, 200, 600, L2gradient = True)    #Canny找边缘
    contours, _ = cv2.findContours(edged, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE) #findContours找角点
    if len(contours) > 0:
        #筛选出最大的轮廓
        largest_contour = max(contours, key=cv2.contourArea)
    
        epsilon =0.02 * cv2.arcLength(largest_contour,True)
        approx = cv2.approxPolyDP(largest_contour, epsilon, True) #approxPolyDP逼近多边形   approx格式为:[[[x1 y1]] [[x2 y2]] [[x3 y3]]]
        # if len(approx) > 10:  #如果角点数>=3
        #     print("这是圆")
        #     cv2.drawContours(img_raw, [approx], 0, (0, 255, 0), 3)
        if len(approx) == 3:
            # rect = cv2.minAreaRect(approx)  #获取最小外接矩形
            # points = cv2.boxPoints(rect)     #最小外接矩形的四点(顺序：右下；左下；右上；左上)
            # # center = rect[0]            
            # print(points)
            # cv2.drawContours(img_raw, [approx], 0, (0, 255, 0), 3)   #drawContours画出轮廓
            # for point in approx:
                # x, y = point.ravel()    #获取每个多边形角点坐标
                # cv2.circle(img=img_raw,center=(x,y),radius=5,color=(255,0,0),thickness=2) #circle画出多边形角点
            approx = approx.tolist()                                                  #approx从array转list，防止下面判断报错
            return approx                                                             #不测试的话就把point循环给删了，直接输出approx
                
        elif len(approx) == 4 :
            #cv2.drawContours(img_raw, [approx], 0, (0, 255, 0), 3)   #drawContours画出轮廓
            # for point in approx:
                # x, y = point.ravel()    #获取每个多边形角点坐标
                # cv2.circle(img=img_raw,center=(x,y),radius=5,color=(255,0,0),thickness=2) #circle画出多边形角点
            approx = approx.tolist()
            return approx
'''
def image_processing_1(img):
    time.fps_start()          # Manually set fps calculation start point, comment here mean last time fps() call is start
    #                             # | 动设置帧率（FPS）计算开始点，这里注释了表示上一次 fps 函数即是开始
    circle = Circle_find(thresholds_object1_On, img)
    rectangular = Rectangular_find(img)
    trig = Trig_find(img)
    if circle != None:
        object = [b'\x0A',3,[circle.x(),circle.y(),circle.r()],b'\x4D']   #格式为[形状，参数数量，参数列表，力度]
        circle = None

        return object
    
    elif rectangular !=None:
        object = [b'\x0B',4,rectangular,b'\x46']
        rectangular = None

        return object

    
    elif trig != None:
            object = [b'\x0C',4,trig,b'\x4B']
            trig = None
 
            return object
    #         elif len(trig_a_trapz) == 4:
    #             object = [b'\0D',4,[trig_a_trapz[0][0],trig_a_trapz[1][0],trig_a_trapz[2][0],trig_a_trapz[3][0]],b'\x48']
    #             trig_a_trapz = None

                
    #             return object
    disp.show(img)

