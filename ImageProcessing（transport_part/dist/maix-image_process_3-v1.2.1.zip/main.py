#----------------
# main.py
#----------------
#内容：  创建 摄像头cam, 预处理图像img_ori
#        操作 图像处理函数, 识别函数, 界面操作系统函数
#        
#----------------
#创建时间： 2025.3.6
#创建人：yst2219
#----------------


import os

from numpy import void
os.chdir(os.path.dirname(__file__))

from maix import camera, app, time
#import numpy as np
#import cv2

from UART import Uart, on_received, serial1      #请无视这个红线
from Img_Processing_1 import image_processing_1



cam = camera.Camera(200, 200)       #配置摄像头
cam.skip_frames(30)                 #跳过前三十帧

'''
def Image_Processing():
    while 1:
        img = cam.read()

        disp.show(img)
        #以下是识别蓝色矩形的代码
        #第一种(可能会误测到周边环境)
        blue_blobs = img.find_blobs(thresholds_blue, area_threshold = 100, pixels_threshold = 100)
        rects = img.find_rects(threshold = 69500)
        for b in blue_blobs:
            corners = b.corners()
            RECT = b.rect()
            for a in rects:
                rect = a.rect()
                for i in range(4):
                    img.draw_rect(rect[0],rect[1],rect[2],rect[3],image.COLOR_RED)
                    img.draw_line(corners[i][0], corners[i][1], corners[(i + 1) % 4][0], corners[(i + 1) % 4][1], image.COLOR_BLUE)
                    img.draw_string(rect[0] + 5, rect[1] + 5, "rect", image.COLOR_RED)
                    img.draw_string(rect[0] + 5, rect[1] + 20, "magnitude: " + str(a.magnitude()), image.COLOR_RED)      
        #第二种（反应很慢，但准）
        blue_blobs = img.find_blobs(thresholds_blue, area_threshold = 100, pixels_threshold = 100)
        for b in blue_blobs:
            corners = b.corners()
            RECT = b.rect()
            rects = img.find_rects(roi=[RECT[0]-20000,RECT[1]-20000,RECT[2]+20000,RECT[3]+20000], threshold = 69500)
            for a in rects:
                rect = a.rect()
                for i in range(4):
                    img.draw_rect(rect[0],rect[1],rect[2],rect[3],image.COLOR_RED)
                    img.draw_line(corners[i][0], corners[i][1], corners[(i + 1) % 4][0], corners[(i + 1) % 4][1], image.COLOR_BLUE)
                    img.draw_string(rect[0] + 5, rect[1] + 5, "rect", image.COLOR_RED)
        
    #以下是识别三角形和梯形（近似为四边形）的代码
    while 1:
        img = cam.read()
        red_blobs = img.find_blobs(thresholds_red, area_threshold = 100, pixels_threshold = 100)
        for b in red_blobs:
            corners = b.corners()
            trig = find_polygon(img)  #img为待处理图像,3为所要找的多边形角点数
            trapz = find_polygon(img)
            print(trig)
            disp.show(trig) #输出一次开运算的图像5秒   
'''    
    


def main():
    flag_1= 0
    while not app.need_exit():
        img = cam.read()
        serial1.set_received_callback(on_received) 
        object = image_processing_1(img)
        # print("3")
        if object == None:                  #啥都没有
            continue

        elif object[0] == b'\x01':          #圆形
            if flag_1 ==0 :                 #要稳定识别到两次才算数
                flag_1 += 1
                continue
            else:
                ratio = object[2][2] / 225     # pixel / 0.1mm 
                distance_x = int((100 - object[2][0]) * ratio)     #要求物块在视野内从左到右，否则该值取相反数
                if distance_x > -5 and distance_x < 5:
                    flag_1= 0
                    distance_y = int((object[2][1] - 100) * ratio)  #物块在中心点偏下，则y值为正；反之为负
                    # Info_Processing( distance_x, distance_y)
                    force = object[3]
                    print (distance_x,"\t\t",distance_y,"\t\t",force,"\t\t")
                    # time.sleep_ms(1000)
                    Uart(distance_y,force)

            
        elif object[0] == b'\x02':          #正方形
            if flag_1 ==0:
                flag_1 += 1
                continue
            else:
                ratio = object[2][2] / 225
                ratio += object[2][3] /225
                ratio = ratio / 2
                distance_x = int((100 - object[2][0] - 0.5*object[2][2]) * ratio)
                if distance_x > -2 and distance_x < 2:
                    flag_1= 0
                    distance_y = int(( object[2][1] + 0.5*object[2][3] - 100) * ratio)
                    force = object[3]
                    print (distance_x,"\t\t",distance_y,"\t\t",force,"\t\t")
                    # time.sleep_ms(1000)
                    Uart(distance_y,force)
            
        
        elif object[0] ==b'\x03':           #三角形 [[a,b],[],[],[]]
            if flag_1 ==0:
                flag_1 += 1
                continue
            else:
                x1 = object[2][0][0]
                x2 = object[2][1][0]
                x3 = object[2][2][0]
                y1 = object[2][0][1]
                y2 = object[2][1][1]
                y3 = object[2][2][1]
                center = [int(x1/3+x2/3+x3/3), int(y1/3+y2/3+y3/3)]
                ratio = (((x1-x2) ** 2+(y1-y2) ** 2) ** 0.5) / 450 
                distance_x = int((100 - center[0]) * ratio)
                if distance_x > -5 and distance_x < 5:
                    flag_1= 0
                    distance_y = int((center[1] - 100) * ratio)
                    force = object[3]
                    # print("这是一个3边形")  
                    print (distance_x,"\t\t",distance_y,"\t\t",force,"\t\t")
                    # time.sleep_ms(1000)
                    Uart(distance_y,force)
        
        elif object[0] ==b'\x04':               #梯形
            if flag_1 ==0:
                flag_1 += 1
                continue
            else:
                x1 = object[2][0][0]
                x2 = object[2][1][0]
                x3 = object[2][2][0]
                x4 = object[2][3][0]
                y1 = object[2][0][1]
                y2 = object[2][1][1]
                y3 = object[2][2][1]
                y4 = object[2][3][1]
                center = [int(x1/4+x2/4+x3/4+x4/4),int(y1/4+y2/4+y3/4+y4/4)]
                ratio = (((x1-center[0]) ** 2+(y1-center[1]) ** 2) ** 0.5) / 270    #270mm 为梯形角点到重心的距离
                distance_x = int((100 - center[0]) * ratio)
                if distance_x > -2 and distance_x < 2:   
                    flag_1= 0
                    distance_y = int((center[1] - 100) * ratio)
                    force = object[3]
                    # print("这是一个4边形")
                    print (distance_x,"\t\t",distance_y,"\t\t", force,"\t\t")
                    # time.sleep_ms(1000)
                    Uart(distance_y,force)
        

        # fps = time.fps()                # Calculate FPS between last time fps() call and this time call.
        #                             # | 计算两次 fps 函数调用之间的帧率
        # print(f"time: {1000/fps:.02f}ms, fps: {fps:.02f}")  #在终端打印帧率 (FPS)
        # time.sleep_ms(1000)

if __name__ == "__main__":
    main()
    
