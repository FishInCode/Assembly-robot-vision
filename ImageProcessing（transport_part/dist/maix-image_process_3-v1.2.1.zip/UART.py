
from maix import  uart, pinmap
from struct import pack

from numpy import info

# cam = camera.Camera()
# dis = display.Display()


pinmap.set_pin_function("A19", "UART1_TX")
pinmap.set_pin_function("A18", "UART1_RX")
device = "/dev/ttyS1"
serial1 = uart.UART(device, 115200)
def Uart(info_send1, info_send2):
    devices = uart.list_devices()
    serial = uart.UART(devices[0], 115200, uart.BITS.BITS_8, uart.PARITY.PARITY_NONE, uart.STOP.STOP_1)  
    
    # num = 10
    bytes_content = b'\x01'     #信号开头
    bytes_content += b'\xBB'     #传送带停止指令
    info_send1 += 330 
    bytes_content += b'\x00'
    # bytes_content += pack(">h",info_send1)             #基础值3.3cm 加上传输的y轴偏差量
    bytes_content += info_send2
    bytes_content += b'\xFE'
    print(bytes_content, type(bytes_content))
    serial.write(bytes_content)

def on_received(serial : uart.UART, data :bytes):

    print("received:", data)
    # send back
    serial.write(data)
    print("sent", data)
# def Order():
#     devices = uart.list_devices()
#     serial = uart.UART(devices[0], 115200, uart.BITS.BITS_8, uart.PARITY.PARITY_NONE, uart.STOP.STOP_1)

#     order_content = b'\xAA'   #现在尚未确定命令电机运动的校验码为何，先空着

#     serial.write(order_content)
'''
serial.write_str("hello world")
print("received:", serial.read(timeout = 2000))

cam = camera.Camera()
dis = display.Display()
'''

