#----------------
# main.py
#----------------
#内容：  创建 摄像头cam, 预处理图像img_ori
#        操作 图像处理函数, 识别函数, 界面操作系统函数
#        
#----------------
#创建时间： 2025.3.6
#创建人：yst2219
#----------------


import os

os.chdir(os.path.dirname(__file__))

from cv2 import SUBDIV2D_NEXT_AROUND_LEFT
from maix import camera, app, time
#import numpy as np
#import cv2

# from Grab_Claw_init import cross_recog
import UART      #请无视这个红线
from UART import SUBF, Startframe
from Img_Processing_2 import rotary_control_1, rotary_lib

# from Img_Processing_3 import image_processing_3

flag = 0

cam = camera.Camera(200, 200)       #配置摄像头
cam.skip_frames(30)                 #跳过前三十帧

# def Info_Processing(distance_x,distance_y):
#    return void 

'''
def Uart(info_send1,info_send2,info_send3):
    devices = uart.list_devices()
    serial = uart.UART(devices[0], 115200, uart.BITS.BITS_8, uart.PARITY.PARITY_NONE, uart.STOP.STOP_1)  
    
    # num = 10
    bytes_content = b'\xFE'     #信号开头
    bytes_content += b'\xAA'     #传送带停止指令
    bytes_content += pack("<h",info_send1)      #用char类型会溢出，只能用两个字节
    # bytes_content += pack("<i", num)  #将字符串转成二进制数据

    bytes_content += pack("<h",info_send2)     #一个数值传输量 
    bytes_content += info_send3
    bytes_content += b'\xFF'
    print(bytes_content, type(bytes_content))
    serial.write(bytes_content)
'''

'''
#以下是处理圆的代码
def Circle_proc(objects: list):
    
    # object = [b'\x01',3,[circle.x(),circle.y(),circle.r()]]
    
    ratio = object[2][2] / 225     # pixel / 0.1mm 
    distance_x = int((100 - object[2][0]) * ratio) + 730    #要求物块在视野内从左到右，否则该值取相反数
    distance_y = int((100 - object[2][1]) * ratio)
    # Info_Processing( distance_x, distance_y)
    print (distance_x,"\t\t",distance_y,"\t\t")
    # time.sleep_ms(1000)
    Uart(distance_x,distance_y)
'''

'''
#以下是处理矩形的代码
def Rectangular_proc(objects: lis):
    
    # [b'\x02',4,rectangular]   #rectangular 格式为[x,y(左上点坐标),w(宽度),h(高度)]
    
    ratio = object[2][2] / 225
    ratio += object[2][3] /225
    ratio = ratio / 2
    distance_x = int((100 - object[2][0] - 0.5*object[2][2]) * ratio) + 730
    distance_y = int((100 - object[2][1] - 0.5*object[2][3]) * ratio)

    Uart(distance_x,distance_y)
'''

'''
#以下是处理三角形的代码和梯形（近似为四边形）的代码
def Trig_proc(object:list):

    # object = [b'\x03',3,[trig_a_trapz[0][0],trig_a_trapz[1][0],trig_a_trapz[2][0]]]

    x1 = object[2][0][0]
    x2 = object[2][1][0]
    x3 = object[2][2][0]
    y1 = object[2][0][1]
    y2 = object[2][1][1]
    y3 = object[2][2][1]
    center = [int(x1/3+x2/3+x3/3), int(y1/3+y2/3+y3/3)]
    ratio = (((x1-x2) ** 2+(y1-y2) ** 2) ** 0.5) / 450 
    distance_x = int((100 - center[0]) * ratio) + 730
    distance_y = int((100 - center[1]) * ratio)

    Uart(distance_x,distance_y)
'''

'''
#以下是处理梯形的代码
def Trapz_proc(object:list):

    # object = [b'\04',4,[trig_a_trapz[0][0],trig_a_trapz[1][0],trig_a_trapz[2][0],trig_a_trapz[3][0]]]

    x1 = object[2][0][0]
    x2 = object[2][1][0]
    x3 = object[2][2][0]
    x4 = object[2][3][0]
    y1 = object[2][0][1]
    y2 = object[2][1][1]
    y3 = object[2][2][1]
    y4 = object[2][3][1]
    center = [int(x1/4+x2/4+x3/4+x4/4),int(y1/4+y2/4+y3/4+y4/4)]
    ratio = (((x1-center[0]) ** 2+(y1-center[1]) ** 2) ** 0.5) / 270    #270mm 为梯形角点到重心的距离
    distance_x = int((100 - center[0]) * ratio) + 730
    distance_y = int((100 - center[1]) * ratio)

    Uart(distance_x,distance_y)
'''

'''   
def image_processing(img):

    circle = Circle_find(thresholds_object1, img)
    rectangular = Rectangular_find(thresholds_object2, img)
    if circle != None:
        object = [b'\x01',3,[circle.x(),circle.y(),circle.r()]]   #格式为[形状，参数数量，参数列表]
        circle = None
        
        fps = time.fps()                # Calculate FPS between last time fps() call and this time call.
                                        # | 计算两次 fps 函数调用之间的帧率
        print(f"time: {1000/fps:.02f}ms, fps: {fps:.02f}")  #在终端打印帧率 (FPS)

        return object
    
    elif rectangular !=None:
        object = [b'\x02',4,rectangular]
        rectangular = None
        fps = time.fps()                # Calculate FPS between last time fps() call and this time call.
                                        # | 计算两次 fps 函数调用之间的帧率
        print(f"time: {1000/fps:.02f}ms, fps: {fps:.02f}")  #在终端打印帧率 (FPS)

        return object
 
    # else:
    #     trig_a_trapz = TrigATrapz_find(thresholds_object1, img)
    #     if trig_a_trapz != None:
    #         if len(trig_a_trapz) == 3:
    #             object = [b'\x03',3,[trig_a_trapz[0][0],trig_a_trapz[1][0],trig_a_trapz[2][0]]]
    #             trig_a_trapz = None
    #             fps = time.fps()                # Calculate FPS between last time fps() call and this time call.
    #                                             # | 计算两次 fps 函数调用之间的帧率
    #             print(f"time: {1000/fps:.02f}ms, fps: {fps:.02f}")  #在终端打印帧率 (FPS)
                
    #             return object
    #         else:
    #             object = [b'\04',4,[trig_a_trapz[0][0],trig_a_trapz[1][0],trig_a_trapz[2][0],trig_a_trapz[3][0]]]
    #             trig_a_trapz = None
    #             fps = time.fps()                # Calculate FPS between last time fps() call and this time call.
    #                                             # | 计算两次 fps 函数调用之间的帧率
    #             print(f"time: {1000/fps:.02f}ms, fps: {fps:.02f}")  #在终端打印帧率 (FPS)

    #             return object
    

    disp.show(img)
'''

'''
def Image_Processing():
    while 1:
        img = cam.read()

        disp.show(img)
        #以下是识别蓝色矩形的代码
        #第一种(可能会误测到周边环境)
        blue_blobs = img.find_blobs(thresholds_blue, area_threshold = 100, pixels_threshold = 100)
        rects = img.find_rects(threshold = 69500)
        for b in blue_blobs:
            corners = b.corners()
            RECT = b.rect()
            for a in rects:
                rect = a.rect()
                for i in range(4):
                    img.draw_rect(rect[0],rect[1],rect[2],rect[3],image.COLOR_RED)
                    img.draw_line(corners[i][0], corners[i][1], corners[(i + 1) % 4][0], corners[(i + 1) % 4][1], image.COLOR_BLUE)
                    img.draw_string(rect[0] + 5, rect[1] + 5, "rect", image.COLOR_RED)
                    img.draw_string(rect[0] + 5, rect[1] + 20, "magnitude: " + str(a.magnitude()), image.COLOR_RED)      
        #第二种（反应很慢，但准）
        blue_blobs = img.find_blobs(thresholds_blue, area_threshold = 100, pixels_threshold = 100)
        for b in blue_blobs:
            corners = b.corners()
            RECT = b.rect()
            rects = img.find_rects(roi=[RECT[0]-20000,RECT[1]-20000,RECT[2]+20000,RECT[3]+20000], threshold = 69500)
            for a in rects:
                rect = a.rect()
                for i in range(4):
                    img.draw_rect(rect[0],rect[1],rect[2],rect[3],image.COLOR_RED)
                    img.draw_line(corners[i][0], corners[i][1], corners[(i + 1) % 4][0], corners[(i + 1) % 4][1], image.COLOR_BLUE)
                    img.draw_string(rect[0] + 5, rect[1] + 5, "rect", image.COLOR_RED)
        
    #以下是识别三角形和梯形（近似为四边形）的代码
    while 1:
        img = cam.read()
        red_blobs = img.find_blobs(thresholds_red, area_threshold = 100, pixels_threshold = 100)
        for b in red_blobs:
            corners = b.corners()
            trig = find_polygon(img)  #img为待处理图像,3为所要找的多边形角点数
            trapz = find_polygon(img)
            print(trig)
            disp.show(trig) #输出一次开运算的图像5秒   
'''    

def main():
    global SUBF
    global rotary_lib
    global flag
    while not app.need_exit():
        # flag_2 = 0
        img = cam.read()

        ao_count = 0
        SUBF = UART.received(UART.serial0)
        time.sleep_ms(100) # sleep to make CPU free
        # print(SUBF)
        rotary_control_1(SUBF)

        

        for i in range(0,8):
            ao = rotary_lib[i][1]
            if ao:
                ao_count +=1
        if ao_count == 8:
            if flag == 0:
                flag = 1
                continue
            else:
                UART.Uart(8,0)      #示意单片机进入 只抓不塞 模式
                break

        # object = Img_Processing_2.image_processing_2(img)
        # fps = time.fps()                # Calculate FPS between last time fps() call and this time call.
        #                             # | 计算两次 fps 函数调用之间的帧率
        # print(f"time: {1000/fps:.02f}ms, fps: {fps:.02f}")  #在终端打印帧率 (FPS)
'''
        if object == None:
            continue
        elif object[0] == b'\x01':         #圆形
            if flag_2 ==0:
                flag_2 += 1
                continue
            else:
                flag_2 = 0
                ratio = object[2][2] / 225     # pixel / 0.1mm 
                distance_x = int((100 - object[2][0]) * ratio) + 730    #要求物块在视野内从左到右，否则该值取相反数
                distance_y = int((100 - object[2][1]) * ratio)
                # Info_Processing( distance_x, distance_y)
                print (distance_x,"\t\t",distance_y,"\t\t")
                # time.sleep_ms(1000)
                UART.Uart(distance_x,distance_y)
            
        elif object[0] == b'\x02':         #正方形
            if flag_2 ==0:
                flag_2 += 1
                continue
            else:
                flag_2 = 0
                ratio = object[2][2] / 225
                ratio += object[2][3] /225
                ratio = ratio / 2
                distance_x = int((100 - object[2][0] - 0.5*object[2][2]) * ratio) + 730
                distance_y = int((100 - object[2][1] - 0.5*object[2][3]) * ratio)

                UART.Uart(distance_x,distance_y)
        
        elif object[0] ==b'\x03':          #三角形 [[a,b],[],[],[]]
            if flag_2 ==0:
                flag_2 += 1
                continue
            else:
                flag_2 = 0
                x1 = object[2][0][0]
                x2 = object[2][1][0]
                x3 = object[2][2][0]
                y1 = object[2][0][1]
                y2 = object[2][1][1]
                y3 = object[2][2][1]
                center = [int(x1/3+x2/3+x3/3), int(y1/3+y2/3+y3/3)]
                ratio = (((x1-x2) ** 2+(y1-y2) ** 2) ** 0.5) / 450 
                distance_x = int((100 - center[0]) * ratio) + 730
                distance_y = int((100 - center[1]) * ratio)

                UART.Uart(distance_x,distance_y)
            
        elif object[0] ==b'\x04':          #梯形
            if flag_2 ==0:
                flag_2 += 1
                continue
            else:
                flag_2 = 0
                x1 = object[2][0][0]
                x2 = object[2][1][0]
                x3 = object[2][2][0]
                x4 = object[2][3][0]
                y1 = object[2][0][1]
                y2 = object[2][1][1]
                y3 = object[2][2][1]
                y4 = object[2][3][1]
                center = [int(x1/4+x2/4+x3/4+x4/4),int(y1/4+y2/4+y3/4+y4/4)]
                ratio = (((x1-center[0]) ** 2+(y1-center[1]) ** 2) ** 0.5) / 270    #270mm 为梯形角点到重心的距离
                distance_x = int((100 - center[0]) * ratio) + 730
                distance_y = int((100 - center[1]) * ratio)

                UART.Uart(distance_x,distance_y)
'''            


if __name__ == "__main__":
    main()
    
